# mec_exam
# Input File xls from KTU converted to csv
# Scans it rename col headings appropriately
# Sort and filter and create csv for creating pdf
